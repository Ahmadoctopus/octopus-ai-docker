
def load_lstm_model():
    return "📈 Dummy LSTM model loaded"
